function stampaPagina() {
    $(".can-hide").hide();

    window.print();

    $('.can-hide').show();
}
