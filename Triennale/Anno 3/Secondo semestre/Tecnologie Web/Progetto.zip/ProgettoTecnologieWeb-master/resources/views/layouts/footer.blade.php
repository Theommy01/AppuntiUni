<div class="footer-col">
    <p>Tutti i diritti sono riservati al nostro sito.</p>
</div>
<div class="footer-col text-right">
    <p>Contattaci</p>
    <a href="tel:+39 06 3782 8347" class="phone-link">
        <img src="{{ asset('assets/images/phone.svg') }}" alt="Telefono">
        +39 06 3782 8347
    </a>
</div>
